package domain;

public  class Person {
	public static String name;
	public static int age;
	public static String city;
}
