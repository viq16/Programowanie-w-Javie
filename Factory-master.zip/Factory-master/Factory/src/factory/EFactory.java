package factory;

public enum EFactory {
	XML,DB;
}
