package factory;

public interface IFactory {
	public String getName();
	public void setName(String n);
	public int getAge();
	public void setAge(int a);
	public String getCity();
	public void setCity(String c);
}
